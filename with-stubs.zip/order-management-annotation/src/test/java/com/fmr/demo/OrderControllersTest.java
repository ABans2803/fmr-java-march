package com.fmr.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import junit.framework.Assert;
@RunWith(SpringRunner.class)
@ContextConfiguration(classes={Config.class})
@ActiveProfiles("qa")
public class OrderControllersTest {
	@Autowired
	OrderController fixture ;
	/*@Test
	public void testGetOrders() {
		fail("Not yet implemented");
	}
*/
//	@Test
	public void testCreate() {
		//1. fixture 2. call MUT 3. verify
		Order order = new Order();
		order.number="AMAZONE123";
		order.price=34.90F;
		order.item="dell";
		order.status=STATUS.OPEN;
		
		boolean result = fixture.create(order);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testCreateFailure() {
		//1. fixture 2. call MUT 3. verify
		Order order = new Order();
		order.number="AMAZONE123";
		order.price=34.90F;
		order.item="dell";
		order.status=STATUS.OPEN;
		
		boolean result = fixture.create(order);
		Assert.assertFalse(result);
	}
/*
	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}*/

}
