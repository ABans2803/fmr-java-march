package com.fmr.demo;

import java.util.List;

public class OrderDAOStub implements IOrderDAO{

	@Override
	public int totalRows() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int save(Order order) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Order> query() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
