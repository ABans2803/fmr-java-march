package com.fmr;

public class Stringdemo {
	public static void main(String[] args) {
		String s1 = "fidelity"; //literal object
		String s2= new String("fidelity"); //string object
//		System.out.println(s1==s2);
//		System.out.println(s1.hashCode());
//		System.out.println(s2.hashCode());
		System.out.println(s1);
		String s3 = s1.concat(", Bangalore");
		System.out.println(s1);
		System.out.println(s3);

	}
}
