package com.fmr.demo;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

//@Component
public class OrderDAO implements IOrderDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public int save(Order order)  {
		
		StringBuffer query = new StringBuffer("INSERT INTO FMR.Order (ordernumber, price, item, status) values('");
		query.append(order.number).append("',").append(order.price).append(",'").append(order.item).append("','")
				.append(order.status).append("')");
		return jdbcTemplate.update(query.toString());
//		int a = 1 / 0;
//		throw new IOException();
	}

	public int totalRows() {
		int result = jdbcTemplate.queryForObject("SELECT COUNT(*) from fmr.order;", Integer.class);
		return result;
	}

	@Override
	public List<Order> query() {
		List<Order> orders = jdbcTemplate.query("SELECT * from fmr.order", new RowMapper<Order>() {
			@Override
			public Order mapRow(ResultSet resultSet, int rowNumber) throws SQLException {
				Order order = new Order();
				order.id = resultSet.getInt("id");
				order.number = resultSet.getString("orderNumber");
				String status = resultSet.getString("status");
				order.status = STATUS.valueOf(status);
				return order;
			}

		});
		return orders;
	}

	@Override
	public int delete(int id) {
		return jdbcTemplate.update("delete from fmr.order where id="+id);
	}
}
