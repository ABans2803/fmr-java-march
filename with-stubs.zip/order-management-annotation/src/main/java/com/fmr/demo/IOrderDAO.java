package com.fmr.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Component;

//@Component
public interface IOrderDAO {
	public int totalRows();
	int save(Order order)  ;
	List<Order> query();
	public int delete(int id);
}