package com.fmr.demo;

import org.springframework.stereotype.Component;

//@Component
public class OrderDAO implements IOrderDAO {
	@Override
	public void save() {
		
	}
}
