package com.fmr.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
@ComponentScan({"com.fmr"})
public class Config {
	/*@Bean
	public OrderService orderService() {
		return new OrderService();
	}
	*/
	@Bean
	 IOrderDAO orderDAO() {
		return new OrderDAO();
	}
}
