package com.fmr.demo;

import org.springframework.stereotype.Component;

//@Component
public interface IOrderDAO {

	void save();

}