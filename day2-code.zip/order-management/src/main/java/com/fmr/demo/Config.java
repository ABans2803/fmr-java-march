package com.fmr.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	@Bean
	public OrderService orderService() {//callback methods
		return new OrderService();
	}
	
	@Bean
	public IOrderDAO orderDAO() {
		return new OrderDAO();
	}
}
