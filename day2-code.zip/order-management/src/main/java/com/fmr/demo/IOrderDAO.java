package com.fmr.demo;

public interface IOrderDAO {

	void save();

}