package com.fmr.demo;

public class OrderDAO implements IOrderDAO {
	@Override
	public void save() {
		
	}
}
