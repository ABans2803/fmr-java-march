package com.fmr.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class OrderService {
	@Autowired//DI
	public IOrderDAO orderDAO1; //dependency injection
	public void save1() {
		orderDAO1.save(); //thread safe operation
	}
}
