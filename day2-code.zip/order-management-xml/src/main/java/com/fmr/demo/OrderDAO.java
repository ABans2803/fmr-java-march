package com.fmr.demo;

public class OrderDAO implements IOrderDAO {
	private String url;
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	@Override
	public void save() {
		
	}
}
