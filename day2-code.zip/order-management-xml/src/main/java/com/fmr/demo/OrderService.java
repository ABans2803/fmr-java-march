package com.fmr.demo;

import java.util.logging.Level;
import java.util.logging.Logger;

//POJO
public class OrderService {
	Logger logger = Logger.getLogger(OrderService.class.toString());
	public void setOrderDAO1(IOrderDAO orderDAO1) {
		this.orderDAO1 = orderDAO1;
	}
	
	public IOrderDAO orderDAO1; //dependency injection
	public void save1(int i) {
		orderDAO1.save(); //thread safe operation
		logger.log(Level.INFO, "service method");
	}
}
