package com.fmr.demo;

public interface IOrderDAO {
	public String getUrl() ;
	public void setUrl(String url) ;
	void save();

}