package com.fmr.demo.aop;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;

public class LoggerAdvice {
	Logger logger = Logger.getLogger(LoggerAdvice.class.toString());

	public void logAdvice(JoinPoint joinpoint) {//advice
		System.out.println(joinpoint.getArgs()[0]);
		logger.log(Level.INFO, "Advice called before method.............."+joinpoint.getArgs()[0]);
	}
	
	public void afterReturningLogger(JoinPoint joinpoint) {
		logger.log(Level.INFO, "Advice called after method.............."+joinpoint.getArgs()[0]);
	}
}
