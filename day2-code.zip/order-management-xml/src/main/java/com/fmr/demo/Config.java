package com.fmr.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;

@Configuration
@EnableAspectJAutoProxy
@ImportResource({ "dao-context.xml","context.xml"})
public class Config {
	/*@Bean
	public OrderService orderService() {//callback methods
		return new OrderService();
	}
	*/
	@Bean
	public IOrderDAO orderDAO() {
		OrderDAO orderDAO = new OrderDAO();
		orderDAO.setUrl("sdfs");
		return orderDAO;
	}
}
