package com.fmr.demo;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@EnableAspectJAutoProxy
@ComponentScan({"com.fmr"})
public class Config {
	/*@Bean
	public OrderService orderService() {
		return new OrderService();
	}
	*/
	
	@Bean
	DataSourceTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource());
	}
	
	@Bean
	 IOrderDAO orderDAO() {
		return new OrderDAO();
	}
	@Bean 
	public DataSource dataSource() {
		return new DriverManagerDataSource("jdbc:mysql://localhost:3306/fmr", "root", "");
	}
	
	@Bean 
	JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(dataSource());
	}
}
