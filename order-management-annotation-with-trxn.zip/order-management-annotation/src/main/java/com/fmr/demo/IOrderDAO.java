package com.fmr.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Component;

//@Component
public interface IOrderDAO {
	public int totalRows();
	void save(Order order) throws IOException ;
	List<Order> query();
}