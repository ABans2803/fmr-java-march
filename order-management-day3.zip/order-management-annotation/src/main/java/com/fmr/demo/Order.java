package com.fmr.demo;
enum STATUS{
	OPEN, DELIVERED, CANCELLED
}
public class Order {
	int id;
	String number;
	String item;
	float price;
	public STATUS status;
}
