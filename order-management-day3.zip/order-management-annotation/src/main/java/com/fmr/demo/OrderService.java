package com.fmr.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
// @Scope("prototype")
public class OrderService {
	@Autowired // DI
	public IOrderDAO orderDAO1; // dependency injection
	@Autowired
	IAddressDAO addressDAO;

	public void save1(Order order) {
		if (order.item != null) {
			orderDAO1.save(order); // thread safe operation
		}
		// int a = 1 / 0;
		System.out.println("save1 was called$$$$$$$$$$$$$$$$$$");
	}
}
