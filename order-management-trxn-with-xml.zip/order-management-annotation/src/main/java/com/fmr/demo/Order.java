package com.fmr.demo;

public class Order {
	int id;
	String number;
	String item;
	float price;
	public STATUS status;
}
