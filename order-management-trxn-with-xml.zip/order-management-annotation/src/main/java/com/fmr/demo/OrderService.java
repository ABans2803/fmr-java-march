package com.fmr.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
// @Scope("prototype")
public class OrderService {
	@Autowired // DI
	public IOrderDAO orderDAO1; // dependency injection
	@Autowired
	IAddressDAO addressDAO;
	
	public List<Order> getOrders(){
		return orderDAO1.query();
	}
	public void save1(Order order) throws IOException {
		if (order.item != null) {
			orderDAO1.save(order); // thread safe operation
		}
		//logic
		/* try {
			int a = 1 / 0;
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		System.out.println("save1 was called$$$$$$$$$$$$$$$$$$");
	}
}
