package com.fmr.demo.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggerAspect {
	@Pointcut("execution(void save1())")
	public void pointcut1() {
		
	}
//	private long start;
	@Before("pointcut1()")
	public void beforeLogger() {
		System.out.println("before advice was called");
	}
	@AfterReturning(value="pointcut1()")
	public void afterLogger() {
		System.out.println("after advice was called");
	}
	@AfterThrowing(value="pointcut1()", throwing="ex")
	public void afterThrowingAdvice(JoinPoint joinPoint, Exception ex) {
		System.out.println("afterThrowingAdvice called"+ex);
		//log the exception the db
	}
	
	
//	@Around(value="pointcut1()")
	public void timer(ProceedingJoinPoint proceedingJoinPoint) {
		 long start = System.currentTimeMillis();
		System.out.println("start time="+ System.currentTimeMillis());
		try {
			proceedingJoinPoint.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		System.out.println("totel  time taken="+ (System.currentTimeMillis() - start));
	}
}
