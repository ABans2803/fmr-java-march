package com.fmr.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class OrderManagementApplication {

	public static void main(String[] args) throws IOException {
		ApplicationContext container = SpringApplication.run(Config.class);
//		OrderService service1 = (OrderService) container.getBean("orderService");
//		service1.save1();
//		OrderService service2 = (OrderService) container.getBean("orderService");
//		System.out.println(service1 == service2);
//		IOrderDAO dao = (IOrderDAO) container.getBean("orderDAO");
//		Order order = new Order();
//		order.number="AMAZONE123";
//		order.price=34.90F;
//		order.item="dell";
//		order.status=STATUS.OPEN;
//		service1.save1(order);
//		List<Order> result = service1.getOrders();
//		System.out.println(result);
//		System.out.println(dao.totalRows());
//		System.out.println(dao);
//		System.out.println(service1.orderDAO1 == dao);
	}
}
