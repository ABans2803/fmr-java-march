package com.fmr.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.fmr.Utils;

@Component
// @Scope("prototype")
public class OrderService {
	@Autowired // DI
	public IOrderDAO orderDAO1; // dependency injection
	@Autowired
	IAddressDAO addressDAO;

	public List<Order> getOrders() {
		return orderDAO1.query();
	}

	public int save1(Order order) {
		return orderDAO1.save(order); // thread safe operation
	}

	public int delete(int id) {
		if (Utils.checkNegative(id)) {
			return orderDAO1.delete(id);
		} else {
			return 0;
		}
	}
}
