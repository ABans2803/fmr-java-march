package com.fmr.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fmr.Utils;

@RestController
public class OrderController {
	@Autowired
	OrderService orderService;

	/*
	 * @RequestMapping(value = "order", method= {RequestMethod.POST}) public String
	 * hello() { System.out.println("called........."); return "fidelity"; }
	 */
	// @RequestMapping(value = "order", method= {RequestMethod.GET})
	@GetMapping("order") // maps /order+get to this method
	public List<Order> getOrders() {
		return orderService.getOrders();
	}

	@PostMapping("order")
	public boolean create(@RequestBody Order order) {
		return orderService.save1(order) ==1? true: false  ;
	}

	@DeleteMapping("order/{id1}")
	public String delete(@PathVariable("id1") int id) {
		if (Utils.checkNegative(id)) {
			return "not allowed";
		} else {
			return orderService.delete(id) == 0 ? "failed" : "success";
		}
	}
	/*
	 * @DeleteMapping("order/{id1}/{item}") public void delete(@PathVariable("id1")
	 * int id, @PathVariable("item") String itemName) { orderService.delete(id); }
	 */
	// http://localhost:8080/order
}
