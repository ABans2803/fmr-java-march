package com.fmr.demo;

public class Order {
	 int id;
	String number;
	String item;
	float price;
	public STATUS status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		if(price<0) {
			throw new IllegalArgumentException(" negative price is not allowed...");
		}
		this.price = price;
	}
}
