package com.fmr.demo;

public interface IAddressDAO {

}
