package com.fmr.demo;

public enum STATUS{
	OPEN, DELIVERED, CANCELLED;
}