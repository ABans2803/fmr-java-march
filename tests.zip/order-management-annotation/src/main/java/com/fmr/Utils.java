package com.fmr;

public class Utils {
	public static boolean checkNegative(int value){
		return value > 0; 
	}
}
