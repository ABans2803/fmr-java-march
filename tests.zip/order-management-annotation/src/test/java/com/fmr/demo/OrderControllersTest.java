package com.fmr.demo;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

import junit.framework.Assert;

public class OrderControllersTest {

	/*@Test
	public void testGetOrders() {
		fail("Not yet implemented");
	}
*/
	@Test
	public void testCreate() {
		//1. fixture 2. call MUT 3. verify
		ApplicationContext container = SpringApplication.run(Config.class);
		OrderController fixture =  container.getBean(OrderController.class);
		Order order = new Order();
		order.number="AMAZONE123";
		order.price=34.90F;
		order.item="dell";
		order.status=STATUS.OPEN;
		
		boolean result = fixture.create(order);
		Assert.assertTrue(result);
	}
/*
	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}*/

}
