package com.fmr.demo.aop;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.aopalliance.aop.Advice;

public class LoggerAdvice implements Advice{
	Logger logger = Logger.getLogger(LoggerAdvice.class.toString());

	public void logAdvice() {//advice
		logger.log(Level.INFO, "service method");
	}
}
