package com.fmr.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class OrderManagementApplication {

	public static void main(String[] args) {
		ApplicationContext container = SpringApplication.run(Config.class, args);
		OrderService service1 = (OrderService) container.getBean("orderService");
//		OrderService service2 = (OrderService) container.getBean("orderService");
		service1.save1();
//		System.out.println(service1 == service2);
//		IOrderDAO dao = (IOrderDAO) container.getBean("orderDAO");
////		System.out.println(dao.setUrl("aknfiknian"));
//		System.out.println(service1.orderDAO1 == dao);
	}
}
