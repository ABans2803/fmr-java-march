package com.fmr;

import org.springframework.stereotype.Component;

import com.fmr.demo.IAddressDAO;

@Component
public class AddressDAO implements IAddressDAO {

}
