package com.fmr.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

//@Component
public class OrderDAO implements IOrderDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public void save(Order order) {
		StringBuffer query = new StringBuffer(
				"INSERT INTO FMR.Order (ordernumber, price, item) values('");
		query.append(order.number).append("',").append(order.price)
		.append(",'").append(order.item).append("')");
		jdbcTemplate.execute(query.toString());
	}

	public int totalRows() {
		int result = jdbcTemplate.queryForObject("SELECT COUNT(*) from fmr.order;", Integer.class);
		return result;
	}
}
