package com.fmr.demo;

import org.springframework.stereotype.Component;

//@Component
public interface IOrderDAO {
	public int totalRows();
	void save(Order order);

}