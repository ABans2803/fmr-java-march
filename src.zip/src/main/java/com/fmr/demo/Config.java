package com.fmr.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	@Bean
	public OrderService orderService() {
		return new OrderService();
	}
	
	@Bean
	public OrderDAO orderDAO() {
		return new OrderDAO();
	}
}
