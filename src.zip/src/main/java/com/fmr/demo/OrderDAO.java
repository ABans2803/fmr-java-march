package com.fmr.demo;

public class OrderDAO {
	
	public void save() {
		
	}
}
