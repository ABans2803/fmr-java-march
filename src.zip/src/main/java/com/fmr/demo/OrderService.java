package com.fmr.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class OrderService {
	@Autowired
	public OrderDAO orderDAO; //dependency injection
	public void save1() {
		orderDAO.save(); //thread safe operation
	}
}
